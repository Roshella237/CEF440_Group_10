// models/Alert.js
const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const alertSchema = new Schema({
  userImage: {
    type: String,
    required: true,
  },
  userName: {
    type: String,
    required: true,
  },
  location: {
    type: String,
    required: true,
  },
  visualDescription: {
    type: String,
    required: true,
  },
  disasterType: {
    type: String,
    required: true,
  },
  date: {
    type: Date,
    required: true,
  },
  status: {
    type: String,
    enum: ["active", "resolved"],
    default: "active",
  },
});

module.exports = mongoose.model("Alert", alertSchema);
