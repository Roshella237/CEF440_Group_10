// controllers.js
const Alert = require("../models/Alert");
const Users = require("../models/user");
const Responders = require("../models/emergencyResponders");
const News = require("../models/news");
const { response } = require("express");

// Get dashboard
exports.getDashboard = (req, res) => {
  res.render("dashboard.ejs");
};

// Get alert page
exports.getAlerts = async (req, res) => {
  try {
    const alerts = await Alert.find();
    res.render("alert.ejs", { alerts });
  } catch (e) {
    console.error(e);
    res.status(500).send("Server Error");
  }
};

// Get emergency add responders page
exports.getAddResponders = (req, res) => {
  res.render("add_responder.ejs");
};

// Add emergency responder
exports.addResponder = (req, res) => {
  res.render("dashboard.ejs");
};

// Get emergency responders page
exports.getResponders = async (req, res) => {
  try {
    const responders = await Responders.find();
    console.log(responders);
    res.render("responder.ejs", { responders });
  } catch (e) {
    print(e);
  }
};

// Get news page
exports.getNews = async (req, res) => {
  try {
    news = await News.find();
    res.render("news.ejs", { news });
  } catch (e) {
    print(e);
  }
};

// Get add news page
exports.getAddNews = (req, res) => {
  res.render("add_news.ejs");
};

// Post new news
exports.addNews = (req, res) => {
  const { title, author, date, content } = req.body;
  const image = req.file ? req.file.filename : "";
  const id = news.length ? news[news.length - 1].id + 1 : 1;
  news.push({ id, title, author, date, content, image });
  res.redirect("/alert");
};

// Get users page
exports.getUsers = async (req, res) => {
  try {
    users = await Users.find();
    res.render("users.ejs", { users });
  } catch (e) {
    print(e);
  }
};
// responder page
exports.addResponder = async (req, res) => {
  const { name, location, contact, category } = req.body;
  try {
    const newResponder = new Responders({ name, location, contact, category });
    await newResponder.save();
    res.redirect("/");
  } catch (e) {
    console.error(e);
    res.status(500).send("Server Error");
  }
};
// add news 
exports.addNews = async (req, res) => {
    const { title, author, date, content } = req.body;
    const image = req.file ? req.file.filename : '';
    try {
        const newNews = new News({ title, author, date, content, image });
        await newNews.save();
        res.redirect('/news');
    } catch (e) {
        console.error(e);
        res.status(500).send("Server Error");
    }
};
