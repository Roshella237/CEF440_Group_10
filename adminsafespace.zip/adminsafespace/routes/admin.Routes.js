// router.js
const express = require("express");
const router = express.Router();
const multer = require('multer');
const {
    getDashboard,
    getAlerts,
    getAddResponders,
    addResponder,
    getResponders,
    getNews,
    getAddNews,
    addNews,
    getUsers,

} = require("../Controllers/admin.Controller");

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'public/uploads/');
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + '-' + file.originalname);
    }
});
const upload = multer({ storage: storage });

// Get dashboard
router.get("/", getDashboard);

// Get alert page
router.get("/alert", getAlerts);

// Get emergency add responders page
router.get("/add_responders", getAddResponders);

// Add emergency responder
router.post("/add_responder", addResponder);

// Get emergency responders page
router.get('/responders', getResponders);

// Get news page
router.get("/news", getNews);

// Get add news page
router.get("/add_news", getAddNews);

// Post new news
router.post('/add_news', upload.single('image'), addNews);

// Get users page
router.get("/user", getUsers);

router.post("/add_responder",addResponder);

router.post("/add_news",addNews);

module.exports = router;
